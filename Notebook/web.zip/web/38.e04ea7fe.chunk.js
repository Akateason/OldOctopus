(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[38],{

/***/ 150:
/***/ (function(module, exports) {

Prism.languages.brainfuck = {
  'pointer': {
    pattern: /<|>/,
    alias: 'keyword'
  },
  'increment': {
    pattern: /\+/,
    alias: 'inserted'
  },
  'decrement': {
    pattern: /-/,
    alias: 'deleted'
  },
  'branching': {
    pattern: /\[|\]/,
    alias: 'important'
  },
  'operator': /[.,]/,
  'comment': /\S+/
};

/***/ })

}]);