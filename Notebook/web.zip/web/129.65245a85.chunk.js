(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[129],{

/***/ 241:
/***/ (function(module, exports) {

Prism.languages.hsts = {
  directive: {
    pattern: /\b(?:max-age=|includeSubDomains|preload)/,
    alias: "keyword"
  },
  safe: {
    pattern: /\d{8,}/,
    alias: "selector"
  },
  unsafe: {
    pattern: /\d{1,7}/,
    alias: "function"
  }
};

/***/ })

}]);