(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[17],{

/***/ 129:
/***/ (function(module, exports) {

Prism.languages.arff = {
  comment: /%.*/,
  string: {
    pattern: /(["'])(?:\\.|(?!\1)[^\\\r\n])*\1/,
    greedy: !0
  },
  keyword: /@(?:attribute|data|end|relation)\b/i,
  number: /\b\d+(?:\.\d+)?\b/,
  punctuation: /[{},]/
};

/***/ })

}]);