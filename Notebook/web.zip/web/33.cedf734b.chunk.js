(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[33],{

/***/ 145:
/***/ (function(module, exports) {

!function (e) {
  var r = /%%?[~:\w]+%?|!\S+!/,
      t = {
    pattern: /\/[a-z?]+(?=[ :]|$):?|-[a-z]\b|--[a-z-]+\b/im,
    alias: "attr-name",
    inside: {
      punctuation: /:/
    }
  },
      n = /"[^"]*"/,
      i = /(?:\b|-)\d+\b/;
  Prism.languages.batch = {
    comment: [/^::.*/m, {
      pattern: /((?:^|[&(])[ \t]*)rem\b(?:[^^&)\r\n]|\^(?:\r\n|[\s\S]))*/im,
      lookbehind: !0
    }],
    label: {
      pattern: /^:.*/m,
      alias: "property"
    },
    command: [{
      pattern: /((?:^|[&(])[ \t]*)for(?: ?\/[a-z?](?:[ :](?:"[^"]*"|\S+))?)* \S+ in \([^)]+\) do/im,
      lookbehind: !0,
      inside: {
        keyword: /^for\b|\b(?:in|do)\b/i,
        string: n,
        parameter: t,
        variable: r,
        number: i,
        punctuation: /[()',]/
      }
    }, {
      pattern: /((?:^|[&(])[ \t]*)if(?: ?\/[a-z?](?:[ :](?:"[^"]*"|\S+))?)* (?:not )?(?:cmdextversion \d+|defined \w+|errorlevel \d+|exist \S+|(?:"[^"]*"|\S+)?(?:==| (?:equ|neq|lss|leq|gtr|geq) )(?:"[^"]*"|\S+))/im,
      lookbehind: !0,
      inside: {
        keyword: /^if\b|\b(?:not|cmdextversion|defined|errorlevel|exist)\b/i,
        string: n,
        parameter: t,
        variable: r,
        number: i,
        operator: /\^|==|\b(?:equ|neq|lss|leq|gtr|geq)\b/i
      }
    }, {
      pattern: /((?:^|[&()])[ \t]*)else\b/im,
      lookbehind: !0,
      inside: {
        keyword: /^else\b/i
      }
    }, {
      pattern: /((?:^|[&(])[ \t]*)set(?: ?\/[a-z](?:[ :](?:"[^"]*"|\S+))?)* (?:[^^&)\r\n]|\^(?:\r\n|[\s\S]))*/im,
      lookbehind: !0,
      inside: {
        keyword: /^set\b/i,
        string: n,
        parameter: t,
        variable: [r, /\w+(?=(?:[*\/%+\-&^|]|<<|>>)?=)/],
        number: i,
        operator: /[*\/%+\-&^|]=?|<<=?|>>=?|[!~_=]/,
        punctuation: /[()',]/
      }
    }, {
      pattern: /((?:^|[&(])[ \t]*@?)\w+\b(?:[^^&)\r\n]|\^(?:\r\n|[\s\S]))*/im,
      lookbehind: !0,
      inside: {
        keyword: /^\w+\b/i,
        string: n,
        parameter: t,
        label: {
          pattern: /(^\s*):\S+/m,
          lookbehind: !0,
          alias: "property"
        },
        variable: r,
        number: i,
        operator: /\^/
      }
    }],
    operator: /[&@]/,
    punctuation: /[()']/
  };
}();

/***/ })

}]);