(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[320],{

/***/ 432:
/***/ (function(module, exports) {

var typescript = Prism.util.clone(Prism.languages.typescript);
Prism.languages.tsx = Prism.languages.extend('jsx', typescript);

/***/ })

}]);