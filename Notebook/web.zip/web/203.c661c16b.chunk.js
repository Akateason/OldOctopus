(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[203],{

/***/ 315:
/***/ (function(module, exports) {

Prism.languages.monkey = {
  string: /"[^"\r\n]*"/,
  comment: [{
    pattern: /^#Rem\s+[\s\S]*?^#End/im,
    greedy: !0
  }, {
    pattern: /'.+/,
    greedy: !0
  }],
  preprocessor: {
    pattern: /(^[ \t]*)#.+/m,
    lookbehind: !0,
    alias: "comment"
  },
  function: /\w+(?=\()/,
  "type-char": {
    pattern: /(\w)[?%#$]/,
    lookbehind: !0,
    alias: "variable"
  },
  number: {
    pattern: /((?:\.\.)?)(?:(?:\b|\B-\.?|\B\.)\d+(?:(?!\.\.)\.\d*)?|\$[\da-f]+)/i,
    lookbehind: !0
  },
  keyword: /\b(?:Void|Strict|Public|Private|Property|Bool|Int|Float|String|Array|Object|Continue|Exit|Import|Extern|New|Self|Super|Try|Catch|Eachin|True|False|Extends|Abstract|Final|Select|Case|Default|Const|Local|Global|Field|Method|Function|Class|End|If|Then|Else|ElseIf|EndIf|While|Wend|Repeat|Until|Forever|For|To|Step|Next|Return|Module|Interface|Implements|Inline|Throw|Null)\b/i,
  operator: /\.\.|<[=>]?|>=?|:?=|(?:[+\-*\/&~|]|\b(?:Mod|Shl|Shr)\b)=?|\b(?:And|Not|Or)\b/i,
  punctuation: /[.,:;()\[\]]/
};

/***/ })

}]);