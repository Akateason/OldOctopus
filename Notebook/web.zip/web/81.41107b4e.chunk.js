(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[81],{

/***/ 193:
/***/ (function(module, exports) {

Prism.languages.eiffel = {
  comment: /--.*/,
  string: [{
    pattern: /"([^[]*)\[[\s\S]*?\]\1"/,
    greedy: !0
  }, {
    pattern: /"([^{]*)\{[\s\S]*?\}\1"/,
    greedy: !0
  }, {
    pattern: /"(?:%\s+%|%.|[^%"\r\n])*"/,
    greedy: !0
  }],
  char: /'(?:%.|[^%'\r\n])+'/,
  keyword: /\b(?:across|agent|alias|all|and|attached|as|assign|attribute|check|class|convert|create|Current|debug|deferred|detachable|do|else|elseif|end|ensure|expanded|export|external|feature|from|frozen|if|implies|inherit|inspect|invariant|like|local|loop|not|note|obsolete|old|once|or|Precursor|redefine|rename|require|rescue|Result|retry|select|separate|some|then|undefine|until|variant|Void|when|xor)\b/i,
  boolean: /\b(?:True|False)\b/i,
  "class-name": {
    pattern: /\b[A-Z][\dA-Z_]*\b/,
    alias: "builtin"
  },
  number: [/\b0[xcb][\da-f](?:_*[\da-f])*\b/i, /(?:\d(?:_*\d)*)?\.(?:(?:\d(?:_*\d)*)?e[+-]?)?\d(?:_*\d)*|\d(?:_*\d)*\.?/i],
  punctuation: /:=|<<|>>|\(\||\|\)|->|\.(?=\w)|[{}[\];(),:?]/,
  operator: /\\\\|\|\.\.\||\.\.|\/[~\/=]?|[><]=?|[-+*^=~]/
};

/***/ })

}]);