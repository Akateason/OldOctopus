(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[321],{

/***/ 433:
/***/ (function(module, exports) {

var typescript = Prism.util.clone(Prism.languages.typescript);
Prism.languages.tsx = Prism.languages.extend("jsx", typescript);

/***/ })

}]);