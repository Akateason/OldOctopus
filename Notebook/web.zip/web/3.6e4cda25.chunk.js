(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[3],{

/***/ 115:
/***/ (function(module, exports) {

!function (n) {
  var i = "(?:ALPHA|BIT|CHAR|CR|CRLF|CTL|DIGIT|DQUOTE|HEXDIG|HTAB|LF|LWSP|OCTET|SP|VCHAR|WSP)";
  Prism.languages.abnf = {
    comment: /;.*/,
    string: {
      pattern: /(?:%[is])?"[^"\n\r]*"/,
      greedy: !0,
      inside: {
        punctuation: /^%[is]/
      }
    },
    range: {
      pattern: /%(?:b[01]+-[01]+|d\d+-\d+|x[A-F\d]+-[A-F\d]+)/i,
      alias: "number"
    },
    terminal: {
      pattern: /%(?:b[01]+(?:\.[01]+)*|d\d+(?:\.\d+)*|x[A-F\d]+(?:\.[A-F\d]+)*)/i,
      alias: "number"
    },
    repetition: {
      pattern: /(^|[^\w-])(?:\d*\*\d*|\d+)/,
      lookbehind: !0,
      alias: "operator"
    },
    definition: {
      pattern: /(^[ \t]*)(?:[a-z][\w-]*|<[^>\r\n]*>)(?=\s*=)/m,
      lookbehind: !0,
      alias: "keyword",
      inside: {
        punctuation: /<|>/
      }
    },
    "core-rule": {
      pattern: RegExp("(?:(^|[^<\\w-])" + i + "|<" + i + ">)(?![\\w-])", "i"),
      lookbehind: !0,
      alias: ["rule", "constant"],
      inside: {
        punctuation: /<|>/
      }
    },
    rule: {
      pattern: /(^|[^<\w-])[a-z][\w-]*|<[^>\r\n]*>/i,
      lookbehind: !0,
      inside: {
        punctuation: /<|>/
      }
    },
    operator: /=\/?|\//,
    punctuation: /[()\[\]]/
  };
}();

/***/ })

}]);