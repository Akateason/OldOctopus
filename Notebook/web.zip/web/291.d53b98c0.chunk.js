(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[291],{

/***/ 403:
/***/ (function(module, exports) {

Prism.languages.scheme = {
  comment: /;.*/,
  string: {
    pattern: /"(?:[^"\\]|\\.)*"|'[^()#'\s]+/,
    greedy: !0
  },
  character: {
    pattern: /#\\(?:[ux][a-fA-F\d]+|[a-zA-Z]+|\S)/,
    alias: "string"
  },
  keyword: {
    pattern: /(\()(?:define(?:-syntax|-library|-values)?|(?:case-)?lambda|let(?:\*|rec)?(?:-values)?|else|if|cond|begin|delay(?:-force)?|parameterize|guard|set!|(?:quasi-)?quote|syntax-rules)(?=[()\s])/,
    lookbehind: !0
  },
  builtin: {
    pattern: /(\()(?:(?:cons|car|cdr|list|call-with-current-continuation|call\/cc|append|abs|apply|eval)\b|null\?|pair\?|boolean\?|eof-object\?|char\?|procedure\?|number\?|port\?|string\?|vector\?|symbol\?|bytevector\?)(?=[()\s])/,
    lookbehind: !0
  },
  number: {
    pattern: /([\s()])[-+]?\d*\.?\d+(?:\s*[-+]\s*\d*\.?\d+i)?\b/,
    lookbehind: !0
  },
  boolean: /#[tf]/,
  operator: {
    pattern: /(\()(?:[-+*%\/]|[<>]=?|=>?)(?=\s|$)/,
    lookbehind: !0
  },
  function: {
    pattern: /(\()[^()'\s]+(?=[()\s)]|$)/,
    lookbehind: !0
  },
  punctuation: /[()']/
};

/***/ })

}]);