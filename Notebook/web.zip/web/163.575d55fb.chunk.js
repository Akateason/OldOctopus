(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[163],{

/***/ 275:
/***/ (function(module, exports) {

!function (n) {
  var e = /("|')(?:\\(?:\r\n?|\n|.)|(?!\1)[^\\\r\n])*\1/;
  n.languages.json5 = n.languages.extend("json", {
    property: [{
      pattern: RegExp(e.source + "(?=\\s*:)"),
      greedy: !0
    }, {
      pattern: /[_$a-zA-Z\xA0-\uFFFF][$\w\xA0-\uFFFF]*(?=\s*:)/,
      alias: "unquoted"
    }],
    string: {
      pattern: e,
      greedy: !0
    },
    number: /[+-]?(?:NaN|Infinity|0x[a-fA-F\d]+|(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?)/
  });
}(Prism);

/***/ })

}]);