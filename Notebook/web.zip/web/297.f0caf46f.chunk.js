(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[297],{

/***/ 409:
/***/ (function(module, exports) {

!function (n) {
  n.languages.smarty = {
    comment: /\{\*[\s\S]*?\*\}/,
    delimiter: {
      pattern: /^\{|\}$/i,
      alias: "punctuation"
    },
    string: /(["'])(?:\\.|(?!\1)[^\\\r\n])*\1/,
    number: /\b0x[\dA-Fa-f]+|(?:\b\d+\.?\d*|\B\.\d+)(?:[Ee][-+]?\d+)?/,
    variable: [/\$(?!\d)\w+/, /#(?!\d)\w+#/, {
      pattern: /(\.|->)(?!\d)\w+/,
      lookbehind: !0
    }, {
      pattern: /(\[)(?!\d)\w+(?=\])/,
      lookbehind: !0
    }],
    function: [{
      pattern: /(\|\s*)@?(?!\d)\w+/,
      lookbehind: !0
    }, /^\/?(?!\d)\w+/, /(?!\d)\w+(?=\()/],
    "attr-name": {
      pattern: /\w+\s*=\s*(?:(?!\d)\w+)?/,
      inside: {
        variable: {
          pattern: /(=\s*)(?!\d)\w+/,
          lookbehind: !0
        },
        operator: /=/
      }
    },
    punctuation: [/[\[\]().,:`]|->/],
    operator: [/[+\-*\/%]|==?=?|[!<>]=?|&&|\|\|?/, /\bis\s+(?:not\s+)?(?:div|even|odd)(?:\s+by)?\b/, /\b(?:eq|neq?|gt|lt|gt?e|lt?e|not|mod|or|and)\b/],
    keyword: /\b(?:false|off|on|no|true|yes)\b/
  }, n.hooks.add("before-tokenize", function (e) {
    var t = !1;
    n.languages["markup-templating"].buildPlaceholders(e, "smarty", /\{\*[\s\S]*?\*\}|\{[\s\S]+?\}/g, function (e) {
      return "{/literal}" === e && (t = !1), !t && ("{literal}" === e && (t = !0), !0);
    });
  }), n.hooks.add("after-tokenize", function (e) {
    n.languages["markup-templating"].tokenizePlaceholders(e, "smarty");
  });
}(Prism);

/***/ })

}]);