(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[99],{

/***/ 211:
/***/ (function(module, exports) {

Prism.languages.gcode = {
  comment: /;.*|\B\(.*?\)\B/,
  string: {
    pattern: /"(?:""|[^"])*"/,
    greedy: !0
  },
  keyword: /\b[GM]\d+(?:\.\d+)?\b/,
  property: /\b[A-Z]/,
  checksum: {
    pattern: /\*\d+/,
    alias: "punctuation"
  },
  punctuation: /:/
};

/***/ })

}]);