(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[79],{

/***/ 191:
/***/ (function(module, exports) {

Prism.languages.ebnf = {
  comment: /\(\*[\s\S]*?\*\)/,
  string: {
    pattern: /"[^"\r\n]*"|'[^'\r\n]*'/,
    greedy: !0
  },
  special: {
    pattern: /\?[^?\r\n]*\?/,
    greedy: !0,
    alias: "class-name"
  },
  definition: {
    pattern: /^(\s*)[a-z]\w*(?:[ \t]+[a-z]\w*)*(?=\s*=)/im,
    lookbehind: !0,
    alias: ["rule", "keyword"]
  },
  rule: /[a-z]\w*(?:[ \t]+[a-z]\w*)*/i,
  punctuation: /\([:/]|[:/]\)|[.,;()[\]{}]/,
  operator: /[-=|*/!]/
};

/***/ })

}]);