(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[251],{

/***/ 363:
/***/ (function(module, exports) {

Prism.languages.properties = {
  comment: /^[ \t]*[#!].*$/m,
  "attr-value": {
    pattern: /(^[ \t]*(?:\\(?:\r\n|[\s\S])|[^\\\s:=])+?(?: *[=:] *| ))(?:\\(?:\r\n|[\s\S])|[^\\\r\n])+/m,
    lookbehind: !0
  },
  "attr-name": /^[ \t]*(?:\\(?:\r\n|[\s\S])|[^\\\s:=])+?(?= *[=:] *| )/m,
  punctuation: /[=:]/
};

/***/ })

}]);