(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[125],{

/***/ 237:
/***/ (function(module, exports) {

Prism.languages.hcl = {
  comment: /(?:\/\/|#).*|\/\*[\s\S]*?(?:\*\/|$)/,
  heredoc: {
    pattern: /<<-?(\w+)[\s\S]*?^\s*\1/m,
    greedy: !0,
    alias: "string"
  },
  keyword: [{
    pattern: /(?:resource|data)\s+(?:"(?:\\[\s\S]|[^\\"])*")(?=\s+"[\w-]+"\s+{)/i,
    inside: {
      type: {
        pattern: /(resource|data|\s+)(?:"(?:\\[\s\S]|[^\\"])*")/i,
        lookbehind: !0,
        alias: "variable"
      }
    }
  }, {
    pattern: /(?:provider|provisioner|variable|output|module|backend)\s+(?:[\w-]+|"(?:\\[\s\S]|[^\\"])*")\s+(?={)/i,
    inside: {
      type: {
        pattern: /(provider|provisioner|variable|output|module|backend)\s+(?:[\w-]+|"(?:\\[\s\S]|[^\\"])*")\s+/i,
        lookbehind: !0,
        alias: "variable"
      }
    }
  }, {
    pattern: /[\w-]+(?=\s+{)/
  }],
  property: [/[\w-\.]+(?=\s*=(?!=))/, /"(?:\\[\s\S]|[^\\"])+"(?=\s*[:=])/],
  string: {
    pattern: /"(?:[^\\$"]|\\[\s\S]|\$(?:(?=")|\$+|[^"${])|\$\{(?:[^{}"]|"(?:[^\\"]|\\[\s\S])*")*\})*"/,
    greedy: !0,
    inside: {
      interpolation: {
        pattern: /(^|[^$])\$\{(?:[^{}"]|"(?:[^\\"]|\\[\s\S])*")*\}/,
        lookbehind: !0,
        inside: {
          type: {
            pattern: /(\b(?:terraform|var|self|count|module|path|data|local)\b\.)[\w\*]+/i,
            lookbehind: !0,
            alias: "variable"
          },
          keyword: /\b(?:terraform|var|self|count|module|path|data|local)\b/i,
          function: /\w+(?=\()/,
          string: {
            pattern: /"(?:\\[\s\S]|[^\\"])*"/,
            greedy: !0
          },
          number: /\b0x[\da-f]+|\d+\.?\d*(?:e[+-]?\d+)?/i,
          punctuation: /[!\$#%&'()*+,.\/;<=>@\[\\\]^`{|}~?:]/
        }
      }
    }
  },
  number: /\b0x[\da-f]+|\d+\.?\d*(?:e[+-]?\d+)?/i,
  boolean: /\b(?:true|false)\b/i,
  punctuation: /[=\[\]{}]/
};

/***/ })

}]);