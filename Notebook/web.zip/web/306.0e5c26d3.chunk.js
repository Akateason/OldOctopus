(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[306],{

/***/ 418:
/***/ (function(module, exports) {

Prism.languages.t4 = Prism.languages['t4-cs'] = Prism.languages['t4-templating'].createT4('csharp');

/***/ })

}]);