(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[323],{

/***/ 435:
/***/ (function(module, exports) {

!function (t) {
  t.languages.tt2 = t.languages.extend("clike", {
    comment: {
      pattern: /#.*|\[%#[\s\S]*?%\]/,
      lookbehind: !0
    },
    keyword: /\b(?:BLOCK|CALL|CASE|CATCH|CLEAR|DEBUG|DEFAULT|ELSE|ELSIF|END|FILTER|FINAL|FOREACH|GET|IF|IN|INCLUDE|INSERT|LAST|MACRO|META|NEXT|PERL|PROCESS|RAWPERL|RETURN|SET|STOP|TAGS|THROW|TRY|SWITCH|UNLESS|USE|WHILE|WRAPPER)\b/,
    punctuation: /[[\]{},()]/
  }), t.languages.insertBefore("tt2", "number", {
    operator: /=[>=]?|!=?|<=?|>=?|&&|\|\|?|\b(?:and|or|not)\b/,
    variable: {
      pattern: /[a-z]\w*(?:\s*\.\s*(?:\d+|\$?[a-z]\w*))*/i
    }
  }), t.languages.insertBefore("tt2", "keyword", {
    delimiter: {
      pattern: /^(?:\[%|%%)-?|-?%]$/,
      alias: "punctuation"
    }
  }), t.languages.insertBefore("tt2", "string", {
    "single-quoted-string": {
      pattern: /'[^\\']*(?:\\[\s\S][^\\']*)*'/,
      greedy: !0,
      alias: "string"
    },
    "double-quoted-string": {
      pattern: /"[^\\"]*(?:\\[\s\S][^\\"]*)*"/,
      greedy: !0,
      alias: "string",
      inside: {
        variable: {
          pattern: /\$(?:[a-z]\w*(?:\.(?:\d+|\$?[a-z]\w*))*)/i
        }
      }
    }
  }), delete t.languages.tt2.string, t.hooks.add("before-tokenize", function (e) {
    t.languages["markup-templating"].buildPlaceholders(e, "tt2", /\[%[\s\S]+?%\]/g);
  }), t.hooks.add("after-tokenize", function (e) {
    t.languages["markup-templating"].tokenizePlaceholders(e, "tt2");
  });
}(Prism);

/***/ })

}]);