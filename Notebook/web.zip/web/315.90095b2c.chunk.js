(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[315],{

/***/ 427:
/***/ (function(module, exports) {

Prism.languages.tcl = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0
  },
  string: {
    pattern: /"(?:[^"\\\r\n]|\\(?:\r\n|[\s\S]))*"/,
    greedy: !0
  },
  variable: [{
    pattern: /(\$)(?:::)?(?:[a-zA-Z0-9]+::)*\w+/,
    lookbehind: !0
  }, {
    pattern: /(\$){[^}]+}/,
    lookbehind: !0
  }, {
    pattern: /(^\s*set[ \t]+)(?:::)?(?:[a-zA-Z0-9]+::)*\w+/m,
    lookbehind: !0
  }],
  function: {
    pattern: /(^\s*proc[ \t]+)[^\s]+/m,
    lookbehind: !0
  },
  builtin: [{
    pattern: /(^\s*)(?:proc|return|class|error|eval|exit|for|foreach|if|switch|while|break|continue)\b/m,
    lookbehind: !0
  }, /\b(?:elseif|else)\b/],
  scope: {
    pattern: /(^\s*)(?:global|upvar|variable)\b/m,
    lookbehind: !0,
    alias: "constant"
  },
  keyword: {
    pattern: /(^\s*|\[)(?:after|append|apply|array|auto_(?:execok|import|load|mkindex|qualify|reset)|automkindex_old|bgerror|binary|catch|cd|chan|clock|close|concat|dde|dict|encoding|eof|exec|expr|fblocked|fconfigure|fcopy|file(?:event|name)?|flush|gets|glob|history|http|incr|info|interp|join|lappend|lassign|lindex|linsert|list|llength|load|lrange|lrepeat|lreplace|lreverse|lsearch|lset|lsort|math(?:func|op)|memory|msgcat|namespace|open|package|parray|pid|pkg_mkIndex|platform|puts|pwd|re_syntax|read|refchan|regexp|registry|regsub|rename|Safe_Base|scan|seek|set|socket|source|split|string|subst|Tcl|tcl(?:_endOfWord|_findLibrary|startOf(?:Next|Previous)Word|wordBreak(?:After|Before)|test|vars)|tell|time|tm|trace|unknown|unload|unset|update|uplevel|vwait)\b/m,
    lookbehind: !0
  },
  operator: /!=?|\*\*?|==|&&?|\|\|?|<[=<]?|>[=>]?|[-+~\/%?^]|\b(?:eq|ne|in|ni)\b/,
  punctuation: /[{}()\[\]]/
};

/***/ })

}]);