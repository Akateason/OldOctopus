(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[160],{

/***/ 272:
/***/ (function(module, exports) {

Prism.languages.json = {
  'comment': /\/\/.*|\/\*[\s\S]*?(?:\*\/|$)/,
  'property': {
    pattern: /"(?:\\.|[^\\"\r\n])*"(?=\s*:)/,
    greedy: true
  },
  'string': {
    pattern: /"(?:\\.|[^\\"\r\n])*"(?!\s*:)/,
    greedy: true
  },
  'number': /-?\d+\.?\d*(e[+-]?\d+)?/i,
  'punctuation': /[{}[\],]/,
  'operator': /:/,
  'boolean': /\b(?:true|false)\b/,
  'null': {
    pattern: /\bnull\b/,
    alias: 'keyword'
  }
};

/***/ })

}]);