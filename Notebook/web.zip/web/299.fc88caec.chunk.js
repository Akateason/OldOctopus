(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[299],{

/***/ 411:
/***/ (function(module, exports) {

!function (t) {
  var e = /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      a = /\b\d+(?:\.\d+)?(?:[eE][+-]?\d+)?\b|\b0x[\dA-F]+\b/;
  t.languages.soy = {
    comment: [/\/\*[\s\S]*?\*\//, {
      pattern: /(\s)\/\/.*/,
      lookbehind: !0,
      greedy: !0
    }],
    "command-arg": {
      pattern: /({+\/?\s*(?:alias|call|delcall|delpackage|deltemplate|namespace|template)\s+)\.?[\w.]+/,
      lookbehind: !0,
      alias: "string",
      inside: {
        punctuation: /\./
      }
    },
    parameter: {
      pattern: /({+\/?\s*@?param\??\s+)\.?[\w.]+/,
      lookbehind: !0,
      alias: "variable"
    },
    keyword: [{
      pattern: /({+\/?[^\S\r\n]*)(?:\\[nrt]|alias|call|case|css|default|delcall|delpackage|deltemplate|else(?:if)?|fallbackmsg|for(?:each)?|if(?:empty)?|lb|let|literal|msg|namespace|nil|@?param\??|rb|sp|switch|template|xid)/,
      lookbehind: !0
    }, /\b(?:any|as|attributes|bool|css|float|in|int|js|html|list|map|null|number|string|uri)\b/],
    delimiter: {
      pattern: /^{+\/?|\/?}+$/,
      alias: "punctuation"
    },
    property: /\w+(?==)/,
    variable: {
      pattern: /\$[^\W\d]\w*(?:\??(?:\.\w+|\[[^\]]+]))*/,
      inside: {
        string: {
          pattern: e,
          greedy: !0
        },
        number: a,
        punctuation: /[\[\].?]/
      }
    },
    string: {
      pattern: e,
      greedy: !0
    },
    function: [/\w+(?=\()/, {
      pattern: /(\|[^\S\r\n]*)\w+/,
      lookbehind: !0
    }],
    boolean: /\b(?:true|false)\b/,
    number: a,
    operator: /\?:?|<=?|>=?|==?|!=|[+*/%-]|\b(?:and|not|or)\b/,
    punctuation: /[{}()\[\]|.,:]/
  }, t.hooks.add("before-tokenize", function (e) {
    var a = !1;
    t.languages["markup-templating"].buildPlaceholders(e, "soy", /{{.+?}}|{.+?}|\s\/\/.*|\/\*[\s\S]*?\*\//g, function (e) {
      return "{/literal}" === e && (a = !1), !a && ("{literal}" === e && (a = !0), !0);
    });
  }), t.hooks.add("after-tokenize", function (e) {
    t.languages["markup-templating"].tokenizePlaceholders(e, "soy");
  });
}(Prism);

/***/ })

}]);