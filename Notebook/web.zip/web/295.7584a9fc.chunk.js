(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[295],{

/***/ 407:
/***/ (function(module, exports) {

Prism.languages.smalltalk = {
  comment: /"(?:""|[^"])*"/,
  string: /'(?:''|[^'])*'/,
  symbol: /#[\da-z]+|#(?:-|([+\/\\*~<>=@%|&?!])\1?)|#(?=\()/i,
  "block-arguments": {
    pattern: /(\[\s*):[^\[|]*\|/,
    lookbehind: !0,
    inside: {
      variable: /:[\da-z]+/i,
      punctuation: /\|/
    }
  },
  "temporary-variables": {
    pattern: /\|[^|]+\|/,
    inside: {
      variable: /[\da-z]+/i,
      punctuation: /\|/
    }
  },
  keyword: /\b(?:nil|true|false|self|super|new)\b/,
  character: {
    pattern: /\$./,
    alias: "string"
  },
  number: [/\d+r-?[\dA-Z]+(?:\.[\dA-Z]+)?(?:e-?\d+)?/, /\b\d+(?:\.\d+)?(?:e-?\d+)?/],
  operator: /[<=]=?|:=|~[~=]|\/\/?|\\\\|>[>=]?|[!^+\-*&|,@]/,
  punctuation: /[.;:?\[\](){}]/
};

/***/ })

}]);