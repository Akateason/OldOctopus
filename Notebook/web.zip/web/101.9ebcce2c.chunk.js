(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[101],{

/***/ 213:
/***/ (function(module, exports) {

Prism.languages.gedcom = {
  "line-value": {
    pattern: /(^\s*\d+ +(?:@\w[\w!"$%&'()*+,\-./:;<=>?[\\\]^`{|}~\x80-\xfe #]*@ +)?\w+ +).+/m,
    lookbehind: !0,
    inside: {
      pointer: {
        pattern: /^@\w[\w!"$%&'()*+,\-./:;<=>?[\\\]^`{|}~\x80-\xfe #]*@$/,
        alias: "variable"
      }
    }
  },
  tag: {
    pattern: /(^\s*\d+ +(?:@\w[\w!"$%&'()*+,\-./:;<=>?[\\\]^`{|}~\x80-\xfe #]*@ +)?)\w+/m,
    lookbehind: !0,
    alias: "string"
  },
  level: {
    pattern: /(^\s*)\d+/m,
    lookbehind: !0,
    alias: "number"
  },
  pointer: {
    pattern: /@\w[\w!"$%&'()*+,\-./:;<=>?[\\\]^`{|}~\x80-\xfe #]*@/,
    alias: "variable"
  }
};

/***/ })

}]);