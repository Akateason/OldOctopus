(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[75],{

/***/ 187:
/***/ (function(module, exports) {

!function (e) {
  e.languages.django = {
    comment: /^{#[\s\S]*?#}$/,
    tag: {
      pattern: /(^{%[+-]?\s*)\w+/,
      lookbehind: !0,
      alias: "keyword"
    },
    delimiter: {
      pattern: /^{[{%][+-]?|[+-]?[}%]}$/,
      alias: "punctuation"
    },
    string: {
      pattern: /("|')(?:\\.|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    filter: {
      pattern: /(\|)\w+/,
      lookbehind: !0,
      alias: "function"
    },
    test: {
      pattern: /(\bis\s+(?:not\s+)?)(?!not\b)\w+/,
      lookbehind: !0,
      alias: "function"
    },
    function: /\b[a-z_]\w+(?=\s*\()/i,
    keyword: /\b(?:and|as|by|else|for|if|import|in|is|loop|not|or|recursive|with|without)\b/,
    operator: /[-+*/%=]=?|!=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
    number: /\b\d+(?:\.\d+)?\b/,
    boolean: /[Tt]rue|[Ff]alse|[Nn]one/,
    variable: /\b\w+?\b/,
    punctuation: /[{}[\](),.:;]/
  };
  var n = /{{[\s\S]*?}}|{%[\s\S]*?%}|{#[\s\S]*?#}/g,
      o = e.languages["markup-templating"];
  e.hooks.add("before-tokenize", function (e) {
    o.buildPlaceholders(e, "django", n);
  }), e.hooks.add("after-tokenize", function (e) {
    o.tokenizePlaceholders(e, "django");
  }), e.languages.jinja2 = e.languages.django, e.hooks.add("before-tokenize", function (e) {
    o.buildPlaceholders(e, "jinja2", n);
  }), e.hooks.add("after-tokenize", function (e) {
    o.tokenizePlaceholders(e, "jinja2");
  });
}(Prism);

/***/ })

}]);